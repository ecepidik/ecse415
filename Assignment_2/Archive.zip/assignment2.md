ECSE 415
Assignment 2 
Ece Pidik
260620324

The image files are assumed to be in the ./dataset folder.
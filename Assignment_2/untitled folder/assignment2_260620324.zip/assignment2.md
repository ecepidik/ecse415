ECSE 415
Assignment 2 
Ece Pidik
260620324

The image files are assumed to be in the ./stitching_images folder for image_stitching question.
The image files are assumed to be in the ./dataset folder for classification question.

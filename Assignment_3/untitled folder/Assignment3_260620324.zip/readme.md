For EM part I initially used a library SciPy to calculate the multivariate. I then changed the code and created a function to calculate it without the outer library. However, I didn't delete it from the code and instead just commented it out. This is in case the grader wants to run it with the outer library (the runtime is much faster) otherwise it takes around 5-8 minutes and gives the same result.

For part 3 of the epipolar image I asked my friend (Florence Diep) to share her point with me. She kindly agreed.
